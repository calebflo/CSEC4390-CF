from fastapi import APIRouter
from pydantic import BaseModel
from typing import Optional

router = APIRouter()


# ─── Pydantic Schemas ────────────────────────────────────────────────────────

class DeviceAuditRequest(BaseModel):
    device_id: str


class AttackSimRequest(BaseModel):
    target_device_id: str
    segmented: bool = False


# ─── Static Data ─────────────────────────────────────────────────────────────

DEVICES = [
    {
        "id": "tv",
        "name": "Smart TV",
        "zone": "iot",
        "ip": "192.168.1.12",
        "vendor": "Samsung SmartHub 2021",
        "risk": "Critical",
        "mitre": "T1078.001",
        "credentials": "admin / 1234 (factory default — unchanged)",
        "firmware": "v3.1.4 — 847 days since last update",
        "encryption": "HTTP only on port 8080 (plaintext admin panel)",
        "open_ports": [8080, 443, 1900],
        "vulnerabilities": [
            "Default credentials unchanged since initial setup",
            "Admin panel exposed on LAN via port 8080 (no HTTPS)",
            "Firmware 847 days out of date — 12 known CVEs present",
            "UPnP enabled — device reachable from WAN",
            "No network isolation — same /24 subnet as work laptop",
        ],
        "cves": ["CVE-2021-36260", "CVE-2022-28762"],
        "defenses": [
            "Change admin password immediately — use 16+ char unique credential",
            "Disable or firewall the HTTP admin panel (port 8080)",
            "Enable automatic firmware updates or apply manually",
            "Disable UPnP on router to prevent WAN exposure",
            "Move all IoT devices to isolated VLAN (192.168.10.0/24)",
        ],
    },
    {
        "id": "cam",
        "name": "IP Camera",
        "zone": "iot",
        "ip": "192.168.1.15",
        "vendor": "HikvisionClone v2",
        "risk": "Critical",
        "mitre": "T1040",
        "credentials": "admin / admin (factory default)",
        "firmware": "v1.0.8 — 1,204 days since last update",
        "encryption": "Unencrypted RTSP stream on port 554",
        "open_ports": [554, 8000, 80],
        "vulnerabilities": [
            "Unencrypted RTSP video stream interceptable by anyone on LAN",
            "Default credentials (admin/admin) active — publicly documented",
            "RTSP feed accessible without authentication on port 554",
            "CVE-2021-36260 — remote code execution via web interface",
            "CVE-2023-28771 — authentication bypass in firmware",
        ],
        "cves": ["CVE-2021-36260", "CVE-2023-28771"],
        "defenses": [
            "Change default credentials — disable admin account, create named account",
            "Enable RTSP authentication and TLS encryption (RTSPS)",
            "Isolate to IoT VLAN — block routing to work device subnet",
            "Apply vendor firmware patches for both CVEs immediately",
        ],
    },
    {
        "id": "speaker",
        "name": "Smart Speaker",
        "zone": "iot",
        "ip": "192.168.1.18",
        "vendor": "Amazon Echo Gen3",
        "risk": "Medium",
        "mitre": "T1123",
        "credentials": "Cloud-managed (no local login interface)",
        "firmware": "Auto-updated by vendor",
        "encryption": "TLS to AWS cloud — but microphone always active",
        "open_ports": [443],
        "vulnerabilities": [
            "Always-on microphone captures ambient work conversations",
            "Voice commands can control smart locks, purchases, and other devices",
            "Stores voice history indefinitely on vendor cloud servers",
            "Third-party Alexa Skills can access voice interaction context",
            "Alexa vs Alexa (AvA) — CVE-2022-25809 allowed self-issuing commands",
        ],
        "cves": ["CVE-2022-25809"],
        "defenses": [
            "Mute microphone hardware switch when discussing sensitive work topics",
            "Regularly audit and delete voice history in Alexa app",
            "Disable third-party skills not actively needed",
            "Place device away from home office workspace",
        ],
    },
    {
        "id": "thermo",
        "name": "Thermostat",
        "zone": "iot",
        "ip": "192.168.1.21",
        "vendor": "NestClone v4",
        "risk": "High",
        "mitre": "T1078",
        "credentials": "admin / password123 (weak — in top-1000 list)",
        "firmware": "v2.2.1 — 312 days since last update",
        "encryption": "HTTPS — but TLS certificate validation disabled",
        "open_ports": [80, 443, 8443],
        "vulnerabilities": [
            "Weak password in top-1000 most-common password lists",
            "TLS certificate validation disabled — man-in-the-middle possible",
            "Behavioral occupancy data reveals daily schedule and presence patterns",
            "UPnP port-forwarding active — admin panel reachable from WAN",
        ],
        "cves": [],
        "defenses": [
            "Set strong unique password — enable 2FA on associated cloud account",
            "Re-enable TLS certificate validation in device settings",
            "Disable UPnP port mapping for this device on router",
            "Move to isolated IoT VLAN",
        ],
    },
    {
        "id": "doorbell",
        "name": "Smart Doorbell",
        "zone": "iot",
        "ip": "192.168.1.24",
        "vendor": "RingClone v2",
        "risk": "High",
        "mitre": "T1190",
        "credentials": "Unique (good) — but CVE in auth handshake",
        "firmware": "v4.1.0 — patch available, not yet applied",
        "encryption": "TLS — CVE in handshake implementation allows bypass",
        "open_ports": [443, 8443],
        "vulnerabilities": [
            "CVE-2023-28771 — authentication bypass via malformed TLS handshake",
            "Firmware patch available from vendor — not yet applied (67 days)",
            "Physical button press triggers LAN broadcast — device fingerprint exposed",
        ],
        "cves": ["CVE-2023-28771"],
        "defenses": [
            "Apply available firmware patch immediately — CVE is actively exploited",
            "Enable 2FA on associated cloud account",
            "Review video retention and sharing privacy settings",
        ],
    },
    {
        "id": "laptop",
        "name": "Work Laptop",
        "zone": "work",
        "ip": "192.168.1.100",
        "vendor": "Dell Latitude — CORP-JSMITH-L",
        "risk": "Target",
        "mitre": "T1555.003",
        "credentials": "Domain credentials + VPN certificate (cached in browser)",
        "firmware": "Windows 11 — 3 pending security updates (SMB-related)",
        "encryption": "BitLocker disk encryption — but browser credential store unencrypted",
        "open_ports": [445, 139, 3389],
        "vulnerabilities": [
            "3 pending Windows security updates — includes SMB vulnerability patches",
            "VPN password cached in browser credential store (readable by processes)",
            "Active VPN session creates direct route to corporate network",
            "Hostname CORP-JSMITH-L reveals employer to anyone on same network",
            "RDP enabled on port 3389 — exposed to LAN",
        ],
        "cves": ["CVE-2022-37958"],
        "defenses": [
            "Apply all pending Windows updates immediately",
            "Remove VPN password from browser — use dedicated password manager",
            "Disable RDP if not actively required",
            "Enable Windows Credential Guard to protect cached credentials",
            "Ensure corporate EDR agent is active and reporting to SOC",
        ],
    },
    {
        "id": "corp",
        "name": "Corporate LAN",
        "zone": "corp",
        "ip": "10.0.0.0/8",
        "vendor": "FinsecCorp Internal",
        "risk": "Exposed via VPN",
        "mitre": "T1133",
        "credentials": "Domain-controlled — but reachable via stolen VPN creds",
        "firmware": "Managed infrastructure",
        "encryption": "TLS everywhere — zero-trust architecture in progress",
        "open_ports": [],
        "vulnerabilities": [
            "Fully reachable via VPN — no additional verification once tunnel established",
            "Implicit trust model — VPN = trusted, no per-request re-authentication",
            "Cannot enforce or audit employee home network security posture",
            "UEBA not tuned for remote-work behavioral baselines",
        ],
        "cves": [],
        "defenses": [
            "Enforce zero-trust — verify every request regardless of VPN status",
            "Deploy UEBA to detect anomalous VPN login behavior (time, location, volume)",
            "Require device health attestation before VPN admission (EDR check)",
            "Implement corporate remote work security policy with IoT guidance",
        ],
    },
]

ATTACK_CHAIN = [
    {
        "step": 1,
        "phase": "Reconnaissance",
        "tactic": "T1046",
        "technique": "Network Service Discovery",
        "target_device": "tv",
        "description": (
            "Attacker performs passive scan of 192.168.1.0/24. "
            "Nmap fingerprints 7 devices. Smart TV port 8080 (HTTP admin panel) identified. "
            "Work laptop hostname CORP-JSMITH-L reveals target employer."
        ),
        "simulated_output": [
            "[*] Initiating scan of 192.168.1.0/24",
            "[*] Discovered 7 hosts. Fingerprinting...",
            "[!] 192.168.1.12 — Samsung SmartHub — port 8080 open (HTTP admin)",
            "[!] 192.168.1.15 — IP camera — port 554 (RTSP, no auth required)",
            "[!] 192.168.1.100 — hostname: CORP-JSMITH-L (corporate device)",
            "[*] Corporate target identified. Proceeding to initial access.",
        ],
        "blocked_by_defense": False,
    },
    {
        "step": 2,
        "phase": "Initial Access",
        "tactic": "T1078.001",
        "technique": "Valid Accounts: Default Accounts",
        "target_device": "tv",
        "description": (
            "Default credentials tried against Smart TV admin panel (port 8080). "
            "admin/1234 accepted immediately. Reverse shell installed in device storage. "
            "Persistence survives device reboot."
        ),
        "simulated_output": [
            "[*] Targeting 192.168.1.12 (Smart TV) — port 8080",
            "[!] Trying default credentials: admin / 1234 ...",
            "[!!!] LOGIN SUCCESSFUL — admin panel access granted",
            "[!!!] Shell access via /api/admin/exec endpoint",
            "[*] Installing reverse shell: /data/apps/.sys/beacon",
            "[!!!] Persistence established — survives reboot",
        ],
        "blocked_by_defense": True,
        "defense_block_reason": "Default credentials changed — login rejected (401 Unauthorized)",
    },
    {
        "step": 3,
        "phase": "Discovery",
        "tactic": "T1018",
        "technique": "Remote System Discovery",
        "target_device": "laptop",
        "description": (
            "From compromised TV, ARP scan of full /24 subnet. "
            "No firewall between IoT and work devices — all hosts reachable. "
            "Work laptop SMB ports (445, 139) open. Active VPN process to 203.0.113.45 detected."
        ),
        "simulated_output": [
            "[*] ARP scan from 192.168.1.12 (compromised TV)...",
            "[*] No firewall between IoT and work device subnet",
            "[!] 192.168.1.100 — CORP-JSMITH-L — SMB open (445, 139)",
            "[!] VPN process active: FortiClient → 203.0.113.45",
            "[!] 3 pending Windows updates detected (SMB-related)",
            "[!!!] Corporate pivot target confirmed.",
        ],
        "blocked_by_defense": True,
        "defense_block_reason": "Firewall rule DENY ALL: IoT VLAN (192.168.10.0/24) → Work VLAN (192.168.1.0/24) — host unreachable",
    },
    {
        "step": 4,
        "phase": "Credential Access",
        "tactic": "T1555.003",
        "technique": "Credentials from Web Browsers",
        "target_device": "laptop",
        "description": (
            "Unpatched SMB vulnerability exploited on work laptop. "
            "Code execution achieved. Windows Credential Manager dumped. "
            "VPN password and OAuth session token for M365 extracted from Chrome."
        ),
        "simulated_output": [
            "[*] Exploiting unpatched SMB on 192.168.1.100 (CVE-2022-37958)...",
            "[!!!] Code execution on work laptop achieved",
            "[*] Dumping Windows Credential Manager...",
            "[!!!] VPN password recovered: J$m1th@FinsecVPN2024",
            "[*] Extracting Chrome session tokens...",
            "[!!!] OAuth token for FinsecCorp M365 captured (8hr validity)",
        ],
        "blocked_by_defense": True,
        "defense_block_reason": "SMB patch applied — CVE-2022-37958 not exploitable. VPN password not in browser store.",
    },
    {
        "step": 5,
        "phase": "Lateral Movement",
        "tactic": "T1133",
        "technique": "External Remote Services (VPN)",
        "target_device": "corp",
        "description": (
            "Stolen VPN credentials used from attacker IP. "
            "MFA bypassed using captured OAuth session token. "
            "Full corporate network access achieved. Internal file shares and cloud env enumerated."
        ),
        "simulated_output": [
            "[*] Authenticating to FinsecCorp VPN from 198.51.100.42...",
            "[!] MFA prompted — using captured OAuth token to bypass...",
            "[!!!] VPN authentication successful",
            "[!!!] Inside corporate network — 10.0.0.0/8 reachable",
            "[*] Enumerating file shares, HR systems, source repos...",
            "[!!!] BREACH COMPLETE — root cause: Smart TV default credentials",
        ],
        "blocked_by_defense": True,
        "defense_block_reason": "Attack chain broken at step 2 — lateral movement never reached VPN stage.",
    },
]


# ─── Endpoints ───────────────────────────────────────────────────────────────

@router.get("/")
def module_info():
    return {
        "module": 7,
        "name": "Smart Home → Corporate Network Pivot",
        "description": (
            "Demonstrates how unsegmented home IoT devices create lateral movement "
            "paths to corporate infrastructure via compromised work laptops."
        ),
        "threat_domain": "IoT / Remote Work Security",
        "severity": "Critical",
        "mitre_techniques": ["T1046", "T1078.001", "T1018", "T1555.003", "T1133"],
        "owasp_category": "IoT Top 10 — I1: Weak/Guessable Passwords; I3: Insecure Ecosystem Interfaces",
        "real_world_stat": "29 attack attempts per home network per day (2026)",
        "source": "SecureIoT.house 2026 / IBM X-Force 2026",
    }


@router.get("/devices")
def get_all_devices():
    """Return full device inventory with risk posture for network map rendering."""
    summary = {
        "total": len(DEVICES),
        "critical": sum(1 for d in DEVICES if d["risk"] == "Critical"),
        "high": sum(1 for d in DEVICES if d["risk"] == "High"),
        "vulnerable_pct": round(
            sum(1 for d in DEVICES if d["risk"] in ("Critical", "High", "Target")) / len(DEVICES) * 100
        ),
    }
    return {"devices": DEVICES, "summary": summary}


@router.get("/devices/{device_id}")
def get_device(device_id: str):
    """Return detailed vulnerability profile for a single device."""
    device = next((d for d in DEVICES if d["id"] == device_id), None)
    if not device:
        return {"error": f"Device '{device_id}' not found"}
    return device


@router.post("/audit")
def audit_device(req: DeviceAuditRequest):
    """
    Simulate a vulnerability audit scan on a specific device.
    Returns findings formatted as a scanner would report them.
    All output is synthetic for educational purposes.
    """
    device = next((d for d in DEVICES if d["id"] == req.device_id), None)
    if not device:
        return {"error": "Device not found"}

    findings = []
    severity_score = 0

    if "default" in device["credentials"].lower() or "1234" in device["credentials"] or "admin" in device["credentials"].lower():
        findings.append({
            "finding": "Default credentials active",
            "severity": "Critical",
            "cvss": 9.8,
            "remediation": "Change to a unique, strong password immediately",
        })
        severity_score += 40

    if device["cves"]:
        for cve in device["cves"]:
            findings.append({
                "finding": f"Unpatched vulnerability: {cve}",
                "severity": "Critical" if "36260" in cve or "28771" in cve else "High",
                "cvss": 9.8 if "36260" in cve else 7.5,
                "remediation": "Apply vendor firmware/software patch",
            })
            severity_score += 25

    if "unencrypted" in device["encryption"].lower() or "http only" in device["encryption"].lower():
        findings.append({
            "finding": "Unencrypted communication channel",
            "severity": "High",
            "cvss": 7.4,
            "remediation": "Enable TLS/HTTPS on all device interfaces",
        })
        severity_score += 20

    if len(device.get("open_ports", [])) > 2:
        findings.append({
            "finding": f"Excessive open ports: {device['open_ports']}",
            "severity": "Medium",
            "cvss": 5.3,
            "remediation": "Close all ports not required for device function",
        })
        severity_score += 10

    overall_risk = (
        "Critical" if severity_score >= 60
        else "High" if severity_score >= 35
        else "Medium" if severity_score >= 15
        else "Low"
    )

    return {
        "device_id": device["id"],
        "device_name": device["name"],
        "ip": device["ip"],
        "scan_findings": findings,
        "finding_count": len(findings),
        "overall_risk": overall_risk,
        "risk_score": min(severity_score, 100),
        "recommendation": (
            "Immediate remediation required — device is exploitable as lateral movement pivot"
            if overall_risk == "Critical"
            else "Address findings within 7 days to reduce attack surface"
        ),
    }


@router.get("/attack-chain")
def get_attack_chain():
    """Return the full 5-step MITRE ATT&CK mapped attack chain."""
    return {
        "chain": ATTACK_CHAIN,
        "total_steps": len(ATTACK_CHAIN),
        "summary": (
            "Unsegmented home network allows attacker to pivot from "
            "a compromised IoT device to a work laptop and into the corporate VPN."
        ),
        "root_cause": "Default credentials on Smart TV + flat network (no IoT VLAN segmentation)",
        "mitre_tactics": ["TA0043", "TA0001", "TA0007", "TA0006", "TA0008"],
    }


@router.post("/simulate-step")
def simulate_attack_step(req: AttackSimRequest):
    """
    Simulate a single attack step against a target device.
    If segmented=True, returns the defense outcome instead.
    Fully sandboxed — no real network activity.
    """
    device = next((d for d in DEVICES if d["id"] == req.target_device_id), None)
    if not device:
        return {"error": "Device not found"}

    step = next((s for s in ATTACK_CHAIN if s["target_device"] == req.target_device_id), None)
    if not step:
        return {"error": "No attack step defined for this device"}

    if req.segmented and step["blocked_by_defense"]:
        return {
            "device": device["name"],
            "step": step["step"],
            "phase": step["phase"],
            "tactic": step["tactic"],
            "outcome": "BLOCKED",
            "blocked": True,
            "block_reason": step["defense_block_reason"],
            "simulated_output": [f"[+] BLOCKED — {step['defense_block_reason']}"],
            "educational_note": (
                "Network segmentation and patching break the attack at this step. "
                "The attacker has no path forward."
            ),
        }

    return {
        "device": device["name"],
        "step": step["step"],
        "phase": step["phase"],
        "tactic": step["tactic"],
        "technique": step["technique"],
        "outcome": "SUCCEEDED",
        "blocked": False,
        "simulated_output": step["simulated_output"],
        "next_step": step["step"] + 1 if step["step"] < len(ATTACK_CHAIN) else None,
        "educational_note": step["description"],
    }


@router.get("/stats")
def threat_stats():
    return {
        "attacks_per_home_per_day": 29,
        "iot_devices_with_default_creds_pct": 20,
        "iot_devices_vulnerable_pct": 80,
        "homes_compromised_at_least_once_pct": 38,
        "firmware_outdated_pct": 33,
        "remote_workers_mixing_iot_and_work_devices": "Majority",
        "source": "SecureIoT.house 2026 / IBM X-Force 2026 / Upstream Auto Report 2026",
    }


@router.get("/defense-checklist")
def defense_checklist():
    return {
        "checklist": [
            {
                "priority": 1,
                "control": "Network segmentation",
                "action": "Create a dedicated IoT VLAN (e.g., 192.168.10.0/24). Set firewall rule: IoT VLAN → Work VLAN = DENY ALL.",
                "impact": "Eliminates lateral movement path — compromised IoT device cannot reach work laptop.",
                "effort": "Low — configurable on most home routers ($50+ models)",
                "nist_csf": "PR.AC-5",
            },
            {
                "priority": 2,
                "control": "Change all default credentials",
                "action": "Replace factory passwords on every IoT device. Use a password manager to generate and store unique credentials.",
                "impact": "Blocks initial access step — most IoT attacks rely on default credential lists.",
                "effort": "Low — 15 minutes per device",
                "nist_csf": "PR.AC-1",
            },
            {
                "priority": 3,
                "control": "Firmware patching",
                "action": "Enable auto-update on all IoT devices. For devices without auto-update, set a monthly manual check reminder.",
                "impact": "Eliminates known CVEs as attack vectors. Reduces exploitable surface significantly.",
                "effort": "Low — mostly automated once configured",
                "nist_csf": "PR.IP-12",
            },
            {
                "priority": 4,
                "control": "Remove browser-cached credentials",
                "action": "Do not save VPN or corporate passwords in browser. Use Bitwarden, 1Password, or corporate-approved password manager.",
                "impact": "Removes credential theft target from work laptop memory.",
                "effort": "Low — one-time setup",
                "nist_csf": "PR.AC-7",
            },
            {
                "priority": 5,
                "control": "Apply OS security updates",
                "action": "Enable Windows Update automatic installation. Prioritize patches tagged with SMB, RDP, or LSASS in bulletin.",
                "impact": "Closes exploitation path from compromised IoT device to work laptop.",
                "effort": "Low — automatic if configured",
                "nist_csf": "PR.IP-12",
            },
            {
                "priority": 6,
                "control": "Disable unused services",
                "action": "Turn off UPnP on router. Disable RDP on work laptop if not required. Close unnecessary IoT device ports.",
                "impact": "Reduces discoverable attack surface during reconnaissance phase.",
                "effort": "Low",
                "nist_csf": "PR.IP-1",
            },
        ]
    }

// ─── Add this block to your existing frontend/src/api/client.js ──────────────
//
// Copy the smartHomeApi object below into your client.js file alongside
// the existing aiPhishingApi, promptInjectionApi, etc. exports.
//
// Then add this import to any component that needs it:
//   import { smartHomeApi } from '../../api/client'

export const smartHomeApi = {
  // GET /api/smart-home/
  info: () => api.get('/api/smart-home/'),

  // GET /api/smart-home/devices
  // Returns full device inventory with risk posture
  devices: () => api.get('/api/smart-home/devices'),

  // GET /api/smart-home/devices/:id
  // Returns detailed vulnerability profile for one device
  device: (id) => api.get(`/api/smart-home/devices/${id}`),

  // POST /api/smart-home/audit  { device_id: string }
  // Returns vulnerability scan findings and risk score
  audit: (deviceId) => api.post('/api/smart-home/audit', { device_id: deviceId }),

  // GET /api/smart-home/attack-chain
  // Returns the full 5-step MITRE ATT&CK mapped attack chain
  attackChain: () => api.get('/api/smart-home/attack-chain'),

  // POST /api/smart-home/simulate-step  { target_device_id: string, segmented: bool }
  // Simulates a single attack step — returns success or blocked outcome
  simulateStep: (deviceId, segmented = false) =>
    api.post('/api/smart-home/simulate-step', {
      target_device_id: deviceId,
      segmented,
    }),

  // GET /api/smart-home/stats
  // Returns threat statistics used in stat cards
  stats: () => api.get('/api/smart-home/stats'),

  // GET /api/smart-home/defense-checklist
  // Returns ordered defense checklist with NIST CSF mappings
  defenseChecklist: () => api.get('/api/smart-home/defense-checklist'),
}

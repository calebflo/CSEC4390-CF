import { useState, useEffect, useRef } from 'react'
import ModuleHeader from '../../components/ModuleHeader'
import { StatCard, DefenseCard, SectionTitle, MitreTag } from '../../components/shared'
import { smartHomeApi } from '../../api/client'

// ─── Static fallback data (used when API is not running) ──────────────────────

const FALLBACK_DEVICES = [
  { id:'tv',       name:'Smart TV',       zone:'iot',  ip:'192.168.1.12',  risk:'Critical', mitre:'T1078.001', credentials:'admin / 1234 (default)', firmware:'847 days outdated', encryption:'HTTP only — port 8080', vulnerabilities:['Default credentials unchanged','Admin panel exposed on LAN','12 known CVEs in firmware','No network segmentation'], defenses:['Change admin password','Disable HTTP admin panel','Apply firmware updates','Move to IoT VLAN'] },
  { id:'cam',      name:'IP Camera',      zone:'iot',  ip:'192.168.1.15',  risk:'Critical', mitre:'T1040',     credentials:'admin / admin (default)', firmware:'1,204 days outdated', encryption:'Unencrypted RTSP port 554', vulnerabilities:['Unencrypted video stream on LAN','Default credentials active','No RTSP authentication','CVE-2021-36260 unpatched'], defenses:['Change credentials','Enable RTSP auth + TLS','Isolate to IoT VLAN','Patch CVE-2021-36260'] },
  { id:'speaker',  name:'Smart Speaker',  zone:'iot',  ip:'192.168.1.18',  risk:'Medium',   mitre:'T1123',     credentials:'Cloud-managed', firmware:'Auto-updated', encryption:'TLS — but mic always on', vulnerabilities:['Always-on microphone','Controls locks and purchases','Stores voice history in cloud','Third-party skills have data access'], defenses:['Mute mic during work calls','Delete voice history','Disable unused skills','Place away from work area'] },
  { id:'thermo',   name:'Thermostat',     zone:'iot',  ip:'192.168.1.21',  risk:'High',     mitre:'T1078',     credentials:'admin / password123 (weak)', firmware:'312 days outdated', encryption:'HTTPS — cert validation OFF', vulnerabilities:['Weak password in top-1000 list','TLS cert validation disabled (MITM risk)','Occupancy data leaks daily schedule','UPnP exposes admin panel to WAN'], defenses:['Set strong unique password','Re-enable TLS cert validation','Disable UPnP','Move to IoT VLAN'] },
  { id:'doorbell', name:'Smart Doorbell', zone:'iot',  ip:'192.168.1.24',  risk:'High',     mitre:'T1190',     credentials:'Unique (good)', firmware:'Patch available — not applied', encryption:'TLS — CVE in handshake', vulnerabilities:['CVE-2023-28771 auth bypass','Patch available 67 days — not applied','Button press triggers LAN broadcast'], defenses:['Apply firmware patch NOW','Enable 2FA on cloud account','Review privacy settings'] },
  { id:'laptop',   name:'Work Laptop',    zone:'work', ip:'192.168.1.100', risk:'Target',   mitre:'T1555.003', credentials:'Domain creds + VPN cert cached in browser', firmware:'3 pending SMB updates', encryption:'BitLocker disk — browser creds plaintext', vulnerabilities:['3 pending Windows SMB patches','VPN password cached in Chrome','Active VPN to corporate network','RDP exposed on port 3389'], defenses:['Apply all Windows updates NOW','Remove VPN creds from browser','Use a password manager','Disable RDP if not needed'] },
  { id:'corp',     name:'Corporate LAN',  zone:'corp', ip:'10.0.0.0/8',    risk:'Exposed',  mitre:'T1133',     credentials:'Domain-controlled — reachable via stolen VPN creds', firmware:'Managed infrastructure', encryption:'TLS everywhere — zero-trust in progress', vulnerabilities:['Fully reachable via VPN','No per-request re-authentication','Cannot audit home network posture','UEBA not tuned for remote work'], defenses:['Enforce zero-trust posture','Deploy UEBA for VPN anomalies','Require device health check on VPN','Issue remote work IoT policy'] },
]

const ATTACK_CHAIN = [
  { step:1, phase:'Reconnaissance',    tactic:'T1046',     device:'tv',      color:'warning', output:['[*] Scanning 192.168.1.0/24...','[*] Discovered 7 hosts. Fingerprinting...','[!] 192.168.1.12 — SmartHub — port 8080 open (HTTP admin)','[!] 192.168.1.15 — IP camera — port 554 (RTSP, no auth)','[!] 192.168.1.100 — hostname: CORP-JSMITH-L','[*] Corporate target identified.'] },
  { step:2, phase:'Initial access',    tactic:'T1078.001', device:'tv',      color:'danger',  output:['[*] Targeting 192.168.1.12 — port 8080','[!] Trying: admin / 1234 ...','[!!!] LOGIN SUCCESSFUL — default credentials accepted','[!!!] Shell access via /api/admin/exec','[*] Installing reverse shell: /data/apps/.sys/beacon','[!!!] Persistence established — survives reboot'] },
  { step:3, phase:'Discovery',         tactic:'T1018',     device:'laptop',  color:'danger',  output:['[*] ARP scan from compromised TV (192.168.1.12)...','[*] No firewall between IoT and work device subnets','[!] 192.168.1.100 — CORP-JSMITH-L — SMB open (445, 139)','[!] VPN active: FortiClient → 203.0.113.45 (FinsecCorp)','[!] 3 pending Windows updates (SMB patches)','[!!!] Corporate pivot confirmed.'] },
  { step:4, phase:'Credential access', tactic:'T1555.003', device:'laptop',  color:'danger',  output:['[*] Exploiting unpatched SMB (CVE-2022-37958)...','[!!!] Code execution on CORP-JSMITH-L achieved','[*] Dumping Windows Credential Manager...','[!!!] VPN password recovered: J$m1th@FinsecVPN2024','[*] Extracting Chrome session tokens...','[!!!] M365 OAuth token captured (8hr validity)'] },
  { step:5, phase:'Lateral movement',  tactic:'T1133',     device:'corp',    color:'danger',  output:['[*] Auth to FinsecCorp VPN from 198.51.100.42...','[!] MFA prompted — using captured OAuth token to bypass...','[!!!] VPN auth successful — inside corporate network','[!!!] 10.0.0.0/8 reachable — file shares, cloud env','[*] Enumerating internal targets...','[!!!] BREACH COMPLETE — root cause: Smart TV default creds'] },
]

const DEFENSES = [
  'Create a dedicated IoT VLAN — prevent all routing between IoT and work devices',
  'Change default credentials on every IoT device immediately (admin/admin = instant compromise)',
  'Apply firmware updates — 847-day-old firmware contains 12+ known CVEs',
  'Remove VPN passwords from browser — use a dedicated password manager',
  'Apply all pending OS security patches — especially SMB-related bulletins',
  'Disable UPnP on your router — stops IoT devices being reachable from WAN',
]

const RISK_STYLES = {
  Critical: { dot:'bg-red-500',    badge:'text-red-400 bg-red-400/10 border border-red-400/20' },
  High:     { dot:'bg-orange-500', badge:'text-orange-400 bg-orange-400/10 border border-orange-400/20' },
  Medium:   { dot:'bg-yellow-500', badge:'text-yellow-400 bg-yellow-400/10 border border-yellow-400/20' },
  Target:   { dot:'bg-orange-500', badge:'text-orange-400 bg-orange-400/10 border border-orange-400/20' },
  Exposed:  { dot:'bg-blue-400',   badge:'text-blue-400 bg-blue-400/10 border border-blue-400/20' },
}

const ZONE_LABELS = {
  iot:  { label:'IoT segment — unsegmented (same /24 as work devices)', color:'text-red-400',  border:'border-red-900/40' },
  work: { label:'Work devices',                                          color:'text-green-400', border:'border-green-900/40' },
  corp: { label:'Corporate network (via VPN)',                           color:'text-blue-400',  border:'border-blue-900/40' },
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function SmartHome() {
  const [devices, setDevices]         = useState(FALLBACK_DEVICES)
  const [selected, setSelected]       = useState(null)
  const [attackStep, setAttackStep]   = useState(-1)
  const [isRunning, setIsRunning]     = useState(false)
  const [isDefended, setIsDefended]   = useState(false)
  const [logLines, setLogLines]       = useState([{ type:'muted', text:'// Click a device to inspect it, then run the attack chain.' }])
  const [auditResult, setAuditResult] = useState(null)
  const logRef = useRef(null)

  useEffect(() => {
    smartHomeApi.devices().then(r => setDevices(r.data.devices)).catch(() => {})
  }, [])

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight
  }, [logLines])

  function addLog(type, text) {
    setLogLines(prev => [...prev, { type, text }])
  }

  async function sleep(ms) { return new Promise(r => setTimeout(r, ms)) }

  async function runAttack() {
    if (isRunning) return
    setIsRunning(true)
    setIsDefended(false)
    setAttackStep(-1)
    setLogLines([])
    setAuditResult(null)

    for (let s = 0; s < ATTACK_CHAIN.length; s++) {
      const step = ATTACK_CHAIN[s]
      setAttackStep(s)
      setSelected(step.device)

      for (const line of step.output) {
        const type = line.startsWith('[!!!]') ? 'danger' : line.startsWith('[!]') ? 'warn' : 'info'
        addLog(type, line)
        await sleep(380)
      }
      await sleep(500)
    }

    addLog('muted', '')
    addLog('danger', '[!!!] ROOT CAUSE: Smart TV with default credentials on a flat home network')
    addLog('danger', '[!!!] PATH: IoT device → same subnet → work laptop → VPN → corporate breach')
    addLog('success', '[+] Click "Apply defenses" to see how segmentation stops this attack')
    setIsRunning(false)
  }

  async function applyDefenses() {
    setIsDefended(true)
    setAttackStep(-1)
    setLogLines([])
    setAuditResult(null)

    const lines = [
      { type:'success', text:'[+] Creating IoT VLAN (192.168.10.0/24) — separating IoT from work devices' },
      { type:'success', text:'[+] Firewall rule applied: IoT VLAN → Work VLAN = DENY ALL' },
      { type:'success', text:'[+] Default credentials changed on Smart TV, IP camera, thermostat' },
      { type:'success', text:'[+] Firmware updated — 847-day-old TV firmware now current' },
      { type:'success', text:'[+] Windows updates applied on work laptop (SMB patches installed)' },
      { type:'success', text:'[+] VPN password removed from browser — moved to password manager' },
      { type:'muted',   text:'' },
      { type:'success', text:'[+] Re-running attack chain with defenses active...' },
      { type:'muted',   text:'' },
      { type:'info',    text:'[*] Step 1: Scanning 192.168.1.0/24...' },
      { type:'info',    text:'[*] IoT devices found — but now on isolated VLAN (192.168.10.0/24)' },
      { type:'info',    text:'[*] Step 2: Trying default credentials on Smart TV...' },
      { type:'success', text:'[+] BLOCKED — credentials changed. Login rejected (401 Unauthorized)' },
      { type:'info',    text:'[*] Step 3: Attempting to reach work laptop from IoT segment...' },
      { type:'success', text:'[+] BLOCKED — firewall drops all traffic: IoT VLAN → Work VLAN' },
      { type:'success', text:'[+] BLOCKED — no route to work laptop. Lateral movement impossible.' },
      { type:'muted',   text:'' },
      { type:'success', text:'[+] ATTACK CHAIN BROKEN at step 2. Corporate network never reached.' },
      { type:'success', text:'[+] Segmentation + patching = attacker is trapped in the IoT VLAN.' },
    ]

    for (const line of lines) {
      addLog(line.type, line.text)
      await sleep(250)
    }
  }

  async function auditDevice(deviceId) {
    try {
      const res = await smartHomeApi.audit(deviceId)
      setAuditResult(res.data)
    } catch {
      const d = devices.find(x => x.id === deviceId)
      setAuditResult({
        device_name: d?.name,
        overall_risk: d?.risk === 'Critical' ? 'Critical' : d?.risk,
        risk_score: d?.risk === 'Critical' ? 85 : d?.risk === 'High' ? 60 : 30,
        finding_count: d?.vulnerabilities?.length || 0,
        recommendation: 'Immediate remediation required — device is exploitable',
        scan_findings: (d?.vulnerabilities || []).map((v, i) => ({
          finding: v, severity: i === 0 ? 'Critical' : 'High', cvss: i === 0 ? 9.8 : 7.4,
        })),
      })
    }
  }

  function reset() {
    setAttackStep(-1)
    setIsRunning(false)
    setIsDefended(false)
    setSelected(null)
    setAuditResult(null)
    setLogLines([{ type:'muted', text:'// Click a device to inspect it, then run the attack chain.' }])
  }

  const selectedDevice = devices.find(d => d.id === selected)
  const zones = ['iot', 'work', 'corp']
  const activeAttackDevice = attackStep >= 0 ? ATTACK_CHAIN[Math.min(attackStep, ATTACK_CHAIN.length - 1)].device : null

  return (
    <div className="min-h-full">
      <ModuleHeader
        num="07"
        title="Smart Home → Corporate Network Pivot"
        subtitle="How unsegmented home IoT devices create a lateral movement path into corporate infrastructure"
        severity="Critical"
        mitre="T1078.001 / T1018 / T1133"
        owasp="IoT Top 10 — I1 / I3"
      />

      <div className="p-8 space-y-6">

        {/* Stats row */}
        <div className="grid grid-cols-4 gap-4">
          <StatCard label="Attack attempts / home / day" value="29"    sub="2026 average"              accent="red"    />
          <StatCard label="IoT devices with default creds" value="20%"  sub="publicly documented"       accent="red"    />
          <StatCard label="Homes compromised at least once" value="38%" sub="of connected homes"         accent="orange" />
          <StatCard label="Firmware outdated"              value="33%"  sub="of all IoT devices globally" accent="orange" />
        </div>

        {/* Network map + device inspector */}
        <div className="grid grid-cols-2 gap-6">

          {/* Network map */}
          <div className="space-y-3">
            <SectionTitle>Home network map — click any device to inspect</SectionTitle>
            {zones.map(zone => {
              const z = ZONE_LABELS[zone]
              const zoneDevices = devices.filter(d => d.zone === zone)
              return (
                <div key={zone} className={`border rounded-xl p-3 ${z.border}`} style={{ borderStyle: 'dashed' }}>
                  <p className={`text-xs font-mono mb-2 ${z.color}`}>{z.label}</p>
                  <div className="grid grid-cols-2 gap-2">
                    {zoneDevices.map(d => {
                      const rs = RISK_STYLES[d.risk] || RISK_STYLES.Medium
                      const isActive = activeAttackDevice === d.id && !isDefended
                      const isComp   = isActive && attackStep >= 1
                      const isSelected = selected === d.id
                      return (
                        <button
                          key={d.id}
                          onClick={() => { setSelected(d.id); auditDevice(d.id) }}
                          className={`text-left rounded-lg p-2.5 border transition-all ${
                            isSelected ? 'border-blue-600/60 bg-blue-600/5' :
                            isComp     ? 'border-red-500/60 bg-red-500/10 animate-pulse' :
                            isDefended  ? 'border-green-600/30 bg-green-600/5' :
                            'border-[#1f2937] bg-[#111827] hover:border-[#374151]'
                          }`}
                        >
                          <div className="flex items-center gap-1.5 mb-1">
                            <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${
                              isDefended && zone !== 'corp' ? 'bg-green-500' : rs.dot
                            }`} />
                            <span className="text-xs font-medium text-white truncate">{d.name}</span>
                          </div>
                          <div className="text-xs text-gray-600 font-mono">{d.ip}</div>
                          <div className={`mt-1 text-xs ${isDefended && zone !== 'corp' ? 'text-green-600' : 'text-gray-600'}`}>
                            {isDefended && zone !== 'corp' ? 'secured' : d.risk.toLowerCase()}
                          </div>
                        </button>
                      )
                    })}
                  </div>
                </div>
              )
            })}
          </div>

          {/* Device inspector */}
          <div className="bg-[#111827] border border-[#1f2937] rounded-xl p-4 space-y-3">
            <SectionTitle>Device inspector</SectionTitle>

            {!selectedDevice && (
              <div className="flex items-center justify-center h-48 text-sm text-gray-700 font-mono">
                Click a device to inspect →
              </div>
            )}

            {selectedDevice && (() => {
              const rs = RISK_STYLES[selectedDevice.risk] || RISK_STYLES.Medium
              return (
                <div className="space-y-3 animate-slide-in">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-base font-semibold text-white">{selectedDevice.name}</span>
                    <span className={`text-xs font-mono px-2 py-0.5 rounded ${rs.badge}`}>{selectedDevice.risk}</span>
                    {selectedDevice.mitre && <MitreTag technique={selectedDevice.mitre} />}
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs">
                    {[
                      { label:'IP',          val: selectedDevice.ip },
                      { label:'Credentials', val: selectedDevice.credentials, danger: selectedDevice.risk === 'Critical' },
                      { label:'Firmware',    val: selectedDevice.firmware,    danger: selectedDevice.firmware?.includes('days') },
                      { label:'Encryption',  val: selectedDevice.encryption,  danger: selectedDevice.encryption?.toLowerCase().includes('http') || selectedDevice.encryption?.toLowerCase().includes('unencrypted') },
                    ].map(row => (
                      <div key={row.label} className="bg-[#0d1117] border border-[#1f2937] rounded-lg p-2">
                        <p className="text-gray-600 mb-0.5">{row.label}</p>
                        <p className={row.danger ? 'text-red-400 font-mono' : 'text-gray-400'}>{row.val}</p>
                      </div>
                    ))}
                  </div>

                  {selectedDevice.vulnerabilities?.length > 0 && (
                    <div className="bg-red-400/5 border border-red-400/20 rounded-lg p-3">
                      <p className="text-xs font-mono text-red-600 mb-2">Vulnerabilities found</p>
                      <ul className="space-y-1">
                        {selectedDevice.vulnerabilities.map((v, i) => (
                          <li key={i} className="flex items-start gap-2 text-xs text-red-400/80">
                            <span className="text-red-700 flex-shrink-0 mt-0.5">!</span>
                            <span>{v}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {selectedDevice.defenses?.length > 0 && (
                    <div className="bg-green-400/5 border border-green-400/20 rounded-lg p-3">
                      <p className="text-xs font-mono text-green-600 mb-2">Fixes</p>
                      <ul className="space-y-1">
                        {selectedDevice.defenses.map((d, i) => (
                          <li key={i} className="flex items-start gap-2 text-xs text-green-400/80">
                            <span className="text-green-700 flex-shrink-0">+</span>
                            <span>{d}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {auditResult && (
                    <div className="bg-[#0d1117] border border-[#1f2937] rounded-lg p-3">
                      <p className="text-xs font-mono text-gray-600 mb-2">Audit result</p>
                      <div className="flex items-center gap-3 mb-2">
                        <span className="text-lg font-semibold text-white">{auditResult.risk_score}/100</span>
                        <span className={`text-xs font-mono px-2 py-0.5 rounded ${RISK_STYLES[auditResult.overall_risk]?.badge || ''}`}>
                          {auditResult.overall_risk}
                        </span>
                        <span className="text-xs text-gray-600">{auditResult.finding_count} findings</span>
                      </div>
                      <div className="h-1.5 bg-[#1f2937] rounded-full overflow-hidden">
                        <div className="h-full bg-red-500 rounded-full transition-all duration-700"
                          style={{ width: `${auditResult.risk_score}%` }} />
                      </div>
                    </div>
                  )}
                </div>
              )
            })()}
          </div>
        </div>

        {/* Attack chain simulator */}
        <div className="bg-[#0d1117] border border-[#1f2937] rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <SectionTitle>Attack chain simulator — MITRE ATT&CK mapped</SectionTitle>
            <div className="flex gap-2 flex-wrap">
              <button onClick={runAttack} disabled={isRunning}
                className="text-xs px-4 py-1.5 rounded-lg border border-red-600/50 text-red-400 hover:bg-red-600/10 disabled:opacity-40 transition-colors">
                {isRunning ? 'Simulating...' : 'Run attack chain'}
              </button>
              <button onClick={applyDefenses} disabled={isRunning}
                className="text-xs px-4 py-1.5 rounded-lg border border-green-600/50 text-green-400 hover:bg-green-600/10 disabled:opacity-40 transition-colors">
                Apply defenses
              </button>
              <button onClick={reset}
                className="text-xs px-4 py-1.5 rounded-lg border border-[#1f2937] text-gray-500 hover:bg-[#1f2937] transition-colors">
                Reset
              </button>
            </div>
          </div>

          {/* Phase progress */}
          <div className="flex gap-1">
            {ATTACK_CHAIN.map((s, i) => (
              <div key={i} className="flex-1">
                <div className={`h-1.5 rounded-full transition-all duration-300 ${
                  isDefended ? 'bg-green-500' :
                  i < attackStep ? 'bg-red-500' :
                  i === attackStep ? 'bg-orange-400' :
                  'bg-[#1f2937]'
                }`} />
                <p className="text-xs text-gray-700 mt-1 truncate" style={{fontSize:'9px'}}>{s.phase}</p>
              </div>
            ))}
          </div>

          {/* Log terminal */}
          <div
            ref={logRef}
            className="bg-[#050810] border border-[#1f2937] rounded-lg p-4 font-mono text-xs leading-relaxed overflow-y-auto"
            style={{ minHeight: '160px', maxHeight: '240px' }}
          >
            {logLines.map((line, i) => (
              <div key={i} className={
                line.type === 'danger'  ? 'text-red-400' :
                line.type === 'warn'   ? 'text-yellow-400' :
                line.type === 'info'   ? 'text-blue-400' :
                line.type === 'success'? 'text-green-400' :
                'text-gray-600'
              }>
                {line.text}
              </div>
            ))}
            {isRunning && (
              <span className="text-green-400 animate-pulse">█</span>
            )}
          </div>
        </div>

        {/* Defense playbook */}
        <DefenseCard tips={DEFENSES} />

      </div>
    </div>
  )
}

# Module 7 — Integration Guide

This module drops into your existing CIS 4390 capstone project with
four changes. Follow them in order.

---

## Step 1 — Copy the files

```
module7/
  backend/app/routers/smart_home.py
      → threat-landscape/backend/app/routers/smart_home.py

  frontend/src/modules/smart-home/SmartHome.jsx
      → threat-landscape/frontend/src/modules/smart-home/SmartHome.jsx

  frontend/src/api/smart_home_client_addition.js
      → reference only — copy the export block into your existing client.js
```

---

## Step 2 — Register the router in backend/app/main.py

Add these two lines to your existing main.py:

```python
# At the top with the other router imports:
from app.routers import smart_home

# At the bottom with the other include_router calls:
app.include_router(smart_home.router, prefix="/api/smart-home", tags=["Module 7 – Smart Home"])
```

Your main.py include_router section should then look like:

```python
app.include_router(ai_phishing.router,      prefix="/api/ai-phishing",      tags=["Module 1"])
app.include_router(prompt_injection.router,  prefix="/api/prompt-injection",  tags=["Module 2"])
app.include_router(ransomware.router,        prefix="/api/ransomware",        tags=["Module 3"])
app.include_router(identity.router,          prefix="/api/identity",          tags=["Module 4"])
app.include_router(supply_chain.router,      prefix="/api/supply-chain",      tags=["Module 5"])
app.include_router(iot.router,               prefix="/api/iot",               tags=["Module 6"])
app.include_router(smart_home.router,        prefix="/api/smart-home",        tags=["Module 7"])
```

---

## Step 3 — Add the API client methods to client.js

Open frontend/src/api/client.js and paste the smartHomeApi export
from smart_home_client_addition.js at the bottom of the file, alongside
the other module exports.

---

## Step 4 — Add the route in App.jsx

```jsx
// Add this import at the top with the other module imports:
import SmartHome from './modules/smart-home/SmartHome'

// Add this route inside the <Route path="/" element={<Layout />}> block:
<Route path="modules/smart-home" element={<SmartHome />} />
```

---

## Step 5 — Add the nav link in Layout.jsx

Add this entry to the MODULES array at the top of Layout.jsx:

```jsx
{ path: '/modules/smart-home', label: 'Smart home pivot', num: '07', severity: 'critical' },
```

---

## Step 6 — Add the module card in Dashboard.jsx

Add this entry to the MODULES array in Dashboard.jsx:

```jsx
{
  num: '07', path: '/modules/smart-home',
  title: 'Smart Home → Corporate Pivot',
  description: 'Demonstrates how unsegmented home IoT devices create a lateral movement path into corporate infrastructure via a compromised work laptop.',
  severity: 'Critical', domain: 'IoT / Remote Work',
  mitre: 'T1078.001', stat: '29', statLabel: 'attack attempts per home per day',
},
```

---

## Verify it works

```bash
# Backend — Swagger should show the new endpoints:
http://localhost:8000/docs
# Look for "Module 7 – Smart Home" section

# Test the devices endpoint directly:
curl http://localhost:8000/api/smart-home/devices

# Frontend — navigate to:
http://localhost:5173/modules/smart-home
```

---

## API Endpoints added

| Method | Endpoint                              | Description                              |
|--------|---------------------------------------|------------------------------------------|
| GET    | /api/smart-home/                      | Module info + MITRE mappings             |
| GET    | /api/smart-home/devices               | Full device inventory + risk summary     |
| GET    | /api/smart-home/devices/{id}          | Single device vulnerability profile     |
| POST   | /api/smart-home/audit                 | Vulnerability scan simulation            |
| GET    | /api/smart-home/attack-chain          | Full 5-step MITRE ATT&CK chain           |
| POST   | /api/smart-home/simulate-step         | Single attack step (attack or defended)  |
| GET    | /api/smart-home/stats                 | Threat statistics for stat cards         |
| GET    | /api/smart-home/defense-checklist     | Ordered fixes with NIST CSF mappings     |

---

## Story point tracking (GitHub Issues)

Create these issues on your GitHub Project board before starting:

| Issue | User Story | Points |
|-------|-----------|--------|
| #17 | As a student, I want to see how unsegmented home networks enable corporate breaches so I understand the remote work risk | 5 |
| #18 | As a student, I want to click IoT devices and see their vulnerability profile and audit results | 3 |
| #19 | As a student, I want to run an animated attack chain showing the pivot from smart TV to corporate VPN | 3 |
| #20 | As a student, I want to apply defenses and see the attack chain blocked at each step | 2 |
| #21 | As a developer, I want Module 7 backend router with full device data and simulation endpoints | 3 |

Total: 16 story points → update your README contribution table to 71 pts.
